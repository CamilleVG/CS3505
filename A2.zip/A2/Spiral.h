/* 
 * Camille van Ginkel u0953582 Jan 31, 2022
 */

#ifndef SPIRAL_H
#define SPIRAL_H

class Spiral {
private:
    double x; // data member or instance variable   
    double y;
    double rad1;
    double rad2;
    double radius;
public:
    Spiral(double centerX, double centerY, double startAngle, double startRadius);

    double getTextX();
    double getTextY();
    double getLetterAngle();

    // Operators
    void operator++();
};

#endif // include guard for Spiral.h
